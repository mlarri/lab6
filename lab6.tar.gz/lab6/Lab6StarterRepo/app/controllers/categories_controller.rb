class CategoriesController < ApplicationController
end
