require 'test_helper'

class BookAuthorTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
